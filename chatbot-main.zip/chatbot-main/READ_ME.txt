Initial Setup:

Terminal:
$ cd chatbotweb
$ python -m venv venv ----> this is to create an environment in python
$ cd chatbotweb\venv\Scripts
$ Scripts> activate
$ (venv) pip install Flask torch torchvision nltk

$ (venv) python
>>> import nltk
>>> nltk.download('punkt')
>>>quit()

$ (venv) cd chatbotweb
$ (venv) python train.py

Run :
Open VsCode:
app.py

frontend folder:
Open in VsCode -- Go Live
Open index.html 
